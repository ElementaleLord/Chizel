export interface Repository {
  id: string;
  name: string;
  owner: string;
  description: string;
  stars: number;
  forks: number;
  language: string;
  visibility: "public" | "private";
  defaultBranch: string;
}

export interface Branch {
  name: string;
  lastCommit: string;
  commitCount: number;
}

export interface Commit {
  id: string;
  message: string;
  author: string;
  authorAvatar: string;
  date: string;
  sha: string;
}

export interface PullRequest {
  id: string;
  number: number;
  title: string;
  author: string;
  authorAvatar: string;
  status: "open" | "closed" | "merged";
  branch: string;
  targetBranch: string;
  createdAt: string;
  comments: number;
}

export interface ActivityData {
  date: string;
  commits: number;
}

export const mockUser = {
  username: "johndoe",
  name: "John Doe",
  email: "john.doe@example.com",
  bio: "Full-stack developer passionate about open source",
  avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&h=400&fit=crop",
  location: "San Francisco, CA",
  website: "https://johndoe.dev",
  followers: 342,
  following: 128,
  joinDate: "2022-03-15",
};

export const mockRepositories: Repository[] = [
  {
    id: "1",
    name: "chizel-ui",
    owner: "johndoe",
    description: "Modern UI component library built with React and Tailwind CSS",
    stars: 1234,
    forks: 156,
    language: "TypeScript",
    visibility: "public",
    defaultBranch: "main",
  },
  {
    id: "2",
    name: "data-viz-toolkit",
    owner: "johndoe",
    description: "Interactive data visualization toolkit for web applications",
    stars: 892,
    forks: 94,
    language: "JavaScript",
    visibility: "public",
    defaultBranch: "main",
  },
  {
    id: "3",
    name: "ml-pipeline",
    owner: "johndoe",
    description: "Machine learning pipeline framework for production environments",
    stars: 567,
    forks: 78,
    language: "Python",
    visibility: "private",
    defaultBranch: "develop",
  },
  {
    id: "4",
    name: "api-gateway",
    owner: "johndoe",
    description: "Lightweight API gateway with rate limiting and authentication",
    stars: 445,
    forks: 52,
    language: "Go",
    visibility: "public",
    defaultBranch: "main",
  },
];

export const mockBranches: Branch[] = [
  {
    name: "main",
    lastCommit: "Fix authentication bug",
    commitCount: 342,
  },
  {
    name: "develop",
    lastCommit: "Add new feature flag system",
    commitCount: 289,
  },
  {
    name: "feature/dark-mode",
    lastCommit: "Implement dark mode toggle",
    commitCount: 23,
  },
  {
    name: "bugfix/login-redirect",
    lastCommit: "Fix redirect after login",
    commitCount: 5,
  },
];

export const mockCommits: Commit[] = [
  {
    id: "1",
    message: "Fix authentication bug in login flow",
    author: "John Doe",
    authorAvatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop",
    date: "2026-03-14T10:30:00Z",
    sha: "a3d8f92",
  },
  {
    id: "2",
    message: "Update dependencies to latest versions",
    author: "Jane Smith",
    authorAvatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop",
    date: "2026-03-13T15:45:00Z",
    sha: "b7e2c14",
  },
  {
    id: "3",
    message: "Add unit tests for API endpoints",
    author: "Mike Johnson",
    authorAvatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop",
    date: "2026-03-13T09:20:00Z",
    sha: "c9f1a56",
  },
  {
    id: "4",
    message: "Refactor user service for better performance",
    author: "John Doe",
    authorAvatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop",
    date: "2026-03-12T14:10:00Z",
    sha: "d4a8e23",
  },
  {
    id: "5",
    message: "Implement dark mode theme",
    author: "Sarah Williams",
    authorAvatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop",
    date: "2026-03-12T11:30:00Z",
    sha: "e5b9f34",
  },
  {
    id: "6",
    message: "Fix responsive layout issues on mobile",
    author: "John Doe",
    authorAvatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop",
    date: "2026-03-11T16:55:00Z",
    sha: "f6c2d45",
  },
  {
    id: "7",
    message: "Add documentation for API endpoints",
    author: "Jane Smith",
    authorAvatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop",
    date: "2026-03-11T13:20:00Z",
    sha: "g7d3e56",
  },
  {
    id: "8",
    message: "Optimize database queries",
    author: "Mike Johnson",
    authorAvatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop",
    date: "2026-03-10T10:45:00Z",
    sha: "h8e4f67",
  },
];

export const mockPullRequests: PullRequest[] = [
  {
    id: "1",
    number: 42,
    title: "Add support for OAuth authentication",
    author: "Sarah Williams",
    authorAvatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop",
    status: "open",
    branch: "feature/oauth",
    targetBranch: "main",
    createdAt: "2026-03-13T09:00:00Z",
    comments: 5,
  },
  {
    id: "2",
    number: 41,
    title: "Fix memory leak in data processing",
    author: "Mike Johnson",
    authorAvatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop",
    status: "merged",
    branch: "bugfix/memory-leak",
    targetBranch: "main",
    createdAt: "2026-03-12T14:30:00Z",
    comments: 12,
  },
  {
    id: "3",
    number: 40,
    title: "Implement caching layer for API responses",
    author: "Jane Smith",
    authorAvatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop",
    status: "open",
    branch: "feature/caching",
    targetBranch: "develop",
    createdAt: "2026-03-11T16:20:00Z",
    comments: 8,
  },
  {
    id: "4",
    number: 39,
    title: "Update README with new installation instructions",
    author: "John Doe",
    authorAvatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop",
    status: "merged",
    branch: "docs/readme-update",
    targetBranch: "main",
    createdAt: "2026-03-10T11:15:00Z",
    comments: 3,
  },
  {
    id: "5",
    number: 38,
    title: "Refactor component architecture",
    author: "Sarah Williams",
    authorAvatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop",
    status: "closed",
    branch: "refactor/components",
    targetBranch: "develop",
    createdAt: "2026-03-09T13:45:00Z",
    comments: 15,
  },
];

export const mockActivityData: ActivityData[] = [
  { date: "2026-01-01", commits: 3 },
  { date: "2026-01-02", commits: 5 },
  { date: "2026-01-03", commits: 2 },
  { date: "2026-01-04", commits: 0 },
  { date: "2026-01-05", commits: 7 },
  { date: "2026-01-06", commits: 4 },
  { date: "2026-01-07", commits: 1 },
  { date: "2026-01-08", commits: 6 },
  { date: "2026-01-09", commits: 3 },
  { date: "2026-01-10", commits: 8 },
  { date: "2026-01-11", commits: 2 },
  { date: "2026-01-12", commits: 5 },
  { date: "2026-01-13", commits: 4 },
  { date: "2026-01-14", commits: 0 },
  { date: "2026-01-15", commits: 9 },
  { date: "2026-01-16", commits: 6 },
  { date: "2026-01-17", commits: 3 },
  { date: "2026-01-18", commits: 7 },
  { date: "2026-01-19", commits: 2 },
  { date: "2026-01-20", commits: 5 },
  { date: "2026-01-21", commits: 4 },
  { date: "2026-01-22", commits: 8 },
  { date: "2026-01-23", commits: 1 },
  { date: "2026-01-24", commits: 6 },
  { date: "2026-01-25", commits: 0 },
  { date: "2026-01-26", commits: 3 },
  { date: "2026-01-27", commits: 7 },
  { date: "2026-01-28", commits: 5 },
  { date: "2026-01-29", commits: 2 },
  { date: "2026-01-30", commits: 4 },
  { date: "2026-01-31", commits: 6 },
  { date: "2026-02-01", commits: 3 },
  { date: "2026-02-02", commits: 8 },
  { date: "2026-02-03", commits: 5 },
  { date: "2026-02-04", commits: 2 },
  { date: "2026-02-05", commits: 7 },
  { date: "2026-02-06", commits: 4 },
  { date: "2026-02-07", commits: 0 },
  { date: "2026-02-08", commits: 6 },
  { date: "2026-02-09", commits: 3 },
  { date: "2026-02-10", commits: 9 },
  { date: "2026-02-11", commits: 5 },
  { date: "2026-02-12", commits: 2 },
  { date: "2026-02-13", commits: 7 },
  { date: "2026-02-14", commits: 4 },
  { date: "2026-02-15", commits: 1 },
  { date: "2026-02-16", commits: 8 },
  { date: "2026-02-17", commits: 6 },
  { date: "2026-02-18", commits: 3 },
  { date: "2026-02-19", commits: 5 },
  { date: "2026-02-20", commits: 0 },
  { date: "2026-02-21", commits: 7 },
  { date: "2026-02-22", commits: 4 },
  { date: "2026-02-23", commits: 2 },
  { date: "2026-02-24", commits: 6 },
  { date: "2026-02-25", commits: 9 },
  { date: "2026-02-26", commits: 3 },
  { date: "2026-02-27", commits: 5 },
  { date: "2026-02-28", commits: 8 },
  { date: "2026-03-01", commits: 4 },
  { date: "2026-03-02", commits: 6 },
  { date: "2026-03-03", commits: 2 },
  { date: "2026-03-04", commits: 7 },
  { date: "2026-03-05", commits: 5 },
  { date: "2026-03-06", commits: 3 },
  { date: "2026-03-07", commits: 0 },
  { date: "2026-03-08", commits: 8 },
  { date: "2026-03-09", commits: 6 },
  { date: "2026-03-10", commits: 4 },
  { date: "2026-03-11", commits: 7 },
  { date: "2026-03-12", commits: 5 },
  { date: "2026-03-13", commits: 9 },
  { date: "2026-03-14", commits: 3 },
];
